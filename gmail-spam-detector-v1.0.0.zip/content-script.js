// Gmail Spam Detector Content Script
class GmailSpamDetector {
  constructor() {
    this.deletedEmails = [];
    this.isEnabled = true; // Track if extension is enabled
    this.settings = {
      autoDelete: false,
      logDeletions: true,
      sensitivity: 3,
      autoUnsubscribe: true, // New setting for auto-unsubscribe
      unsubscribeDelay: 2000 // Delay before auto-unsubscribing (2 seconds)
    };
    this.init();
  }

  async init() {
    await this.loadSettings();
    this.setupObserver();
    this.injectUI();
    this.showActiveIndicator(); // Show that extension is active
  }

  async loadSettings() {
    const result = await chrome.storage.sync.get(['spamDetectorSettings']);
    if (result.spamDetectorSettings) {
      this.settings = { ...this.settings, ...result.spamDetectorSettings };
    }
  }

  setupObserver() {
    // Observe for new emails being loaded
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            this.scanForEmails(node);
          }
        });
      });
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  scanForEmails(container) {
    const emailRows = container.querySelectorAll('[role="row"]');
    emailRows.forEach(row => {
      if (this.isEmailRow(row) && !row.dataset.scanned) {
        this.analyzeEmail(row);
        row.dataset.scanned = 'true';
      }
    });
  }

  isEmailRow(row) {
    return row.querySelector('[role="checkbox"]') && 
           row.querySelector('[data-tooltip]') &&
           !row.classList.contains('zA');
  }

  async analyzeEmail(emailRow) {
    // Skip analysis if extension is disabled
    if (!this.isEnabled) return;
    
    const emailData = this.extractEmailData(emailRow);
    if (!emailData) return;

    const spamScore = this.calculateSpamScore(emailData);
    
    if (spamScore >= this.settings.sensitivity) {
      await this.handleSpamEmail(emailRow, emailData, spamScore);
    }

    // Check for unsubscribe links regardless of spam score
    if (this.settings.autoUnsubscribe) {
      await this.checkForUnsubscribeLinks(emailRow, emailData);
    }
  }

  extractEmailData(emailRow) {
    try {
      const senderElement = emailRow.querySelector('[data-tooltip]');
      const subjectElement = emailRow.querySelector('[data-thread-perm-id]');
      const snippetElement = emailRow.querySelector('.bog');

      if (!senderElement || !subjectElement) return null;

      return {
        sender: senderElement.getAttribute('data-tooltip') || senderElement.textContent,
        subject: subjectElement.getAttribute('title') || subjectElement.textContent,
        snippet: snippetElement ? snippetElement.textContent : '',
        timestamp: new Date().toISOString(),
        emailId: emailRow.getAttribute('data-legacy-message-id') || Date.now().toString()
      };
    } catch (error) {
      console.error('Error extracting email data:', error);
      return null;
    }
  }

  calculateSpamScore(emailData) {
    let score = 0;
    const text = `${emailData.subject} ${emailData.snippet}`.toLowerCase();

    // Spam keywords
    const spamKeywords = [
      'sponsored', 'advertisement', 'promotion', 'offer',
      'limited time', 'act now', 'click here', 'unsubscribe',
      'special offer', 'discount', 'sale', 'free trial',
      'exclusive deal', 'limited offer', 'urgent', 'last chance'
    ];

    // Sponsored indicators
    const sponsoredIndicators = [
      '[ad]', '[sponsored]', '[promotion]', '[advertisement]',
      'sponsored content', 'paid partnership', 'advertisement',
      'promoted post', 'sponsored post'
    ];

    // Check for spam keywords
    spamKeywords.forEach(keyword => {
      if (text.includes(keyword)) {
        score += 2;
      }
    });

    // Check for sponsored indicators
    sponsoredIndicators.forEach(indicator => {
      if (text.includes(indicator)) {
        score += 3;
      }
    });

    // Check sender patterns
    if (this.isKnownSpamSender(emailData.sender)) {
      score += 4;
    }

    // Check for excessive punctuation (spam indicator)
    const exclamationCount = (emailData.subject.match(/!/g) || []).length;
    if (exclamationCount > 2) {
      score += 1;
    }

    return score;
  }

  isKnownSpamSender(sender) {
    const spamDomains = [
      'noreply', 'donotreply', 'no-reply', 'marketing',
      'newsletter', 'promotions', 'offers', 'deals'
    ];

    return spamDomains.some(domain => 
      sender.toLowerCase().includes(domain)
    );
  }

  async handleSpamEmail(emailRow, emailData, spamScore) {
    if (this.settings.autoDelete) {
      await this.moveToTrash(emailRow, emailData, spamScore);
    } else {
      this.highlightSpam(emailRow, emailData, spamScore);
    }
  }

  async moveToTrash(emailRow, emailData, spamScore) {
    try {
      // Click the checkbox to select the email
      const checkbox = emailRow.querySelector('[role="checkbox"]');
      if (checkbox) {
        checkbox.click();
        
        // Wait for selection
        await this.sleep(100);
        
        // Find and click the trash button
        const trashButton = document.querySelector('[data-tooltip="Move to Trash"]') ||
                           document.querySelector('[aria-label="Move to Trash"]');
        
        if (trashButton) {
          trashButton.click();
          
          // Log the deletion
          await this.logDeletion(emailData, spamScore);
          
          console.log(`Moved spam email to trash: ${emailData.subject}`);
        }
      }
    } catch (error) {
      console.error('Error moving email to trash:', error);
    }
  }

  highlightSpam(emailRow, emailData, spamScore) {
    emailRow.style.backgroundColor = '#ffebee';
    emailRow.style.borderLeft = '4px solid #f44336';
    
    // Add a small indicator
    const indicator = document.createElement('div');
    indicator.className = 'spam-indicator';
    indicator.textContent = 'SPAM';
    indicator.style.cssText = `
      position: absolute;
      right: 10px;
      top: 50%;
      transform: translateY(-50%);
      background: #f44336;
      color: white;
      padding: 2px 6px;
      border-radius: 3px;
      font-size: 10px;
      font-weight: bold;
    `;
    
    emailRow.style.position = 'relative';
    emailRow.appendChild(indicator);
  }

  // NEW: Auto-unsubscribe functionality
  async checkForUnsubscribeLinks(emailRow, emailData) {
    try {
      // Click on the email to open it
      const emailLink = emailRow.querySelector('a[href*="mail.google.com"]');
      if (emailLink) {
        emailLink.click();
        
        // Wait for email content to load
        await this.sleep(1000);
        
        // Look for unsubscribe links in the email content
        const unsubscribeLinks = this.findUnsubscribeLinks();
        
        if (unsubscribeLinks.length > 0) {
          console.log(`Found ${unsubscribeLinks.length} unsubscribe link(s) in email from ${emailData.sender}`);
          
          // Show unsubscribe notification
          this.showUnsubscribeNotification(emailData.sender, unsubscribeLinks.length);
          
          // Auto-unsubscribe if enabled
          if (this.settings.autoUnsubscribe) {
            await this.autoUnsubscribe(emailData, unsubscribeLinks);
          }
        }
      }
    } catch (error) {
      console.error('Error checking for unsubscribe links:', error);
    }
  }

  findUnsubscribeLinks() {
    const unsubscribePatterns = [
      'unsubscribe',
      'opt-out',
      'opt out',
      'remove me',
      'remove from list',
      'cancel subscription',
      'stop emails',
      'unsub'
    ];

    const links = [];
    const allLinks = document.querySelectorAll('a[href]');

    allLinks.forEach(link => {
      const href = link.href.toLowerCase();
      const text = link.textContent || link.text || '';
      
      unsubscribePatterns.forEach(pattern => {
        if (href.includes(pattern) || text.toLowerCase().includes(pattern)) {
          links.push({
            element: link,
            href: link.href,
            text: text,
            pattern: pattern
          });
        }
      });
    });

    return links;
  }

  showUnsubscribeNotification(sender, linkCount) {
    // Create notification
    const notification = document.createElement('div');
    notification.className = 'unsubscribe-notification';
    notification.innerHTML = `
      <div style="
        position: fixed;
        top: 20px;
        right: 20px;
        background: #2196f3;
        color: white;
        padding: 15px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        max-width: 300px;
        font-family: Arial, sans-serif;
        font-size: 14px;
      ">
        <div style="font-weight: bold; margin-bottom: 8px;">🔄 Auto-Unsubscribe</div>
        <div>Found ${linkCount} unsubscribe link(s) in email from ${sender}</div>
        <div style="margin-top: 10px; font-size: 12px;">
          <button id="unsubscribe-now" style="
            background: #ff5722;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 8px;
          ">Unsubscribe Now</button>
          <button id="dismiss-notification" style="
            background: transparent;
            color: white;
            border: 1px solid white;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
          ">Dismiss</button>
        </div>
      </div>
    `;

    document.body.appendChild(notification);

    // Add event listeners
    notification.querySelector('#unsubscribe-now').addEventListener('click', () => {
      this.triggerUnsubscribe();
      notification.remove();
    });

    notification.querySelector('#dismiss-notification').addEventListener('click', () => {
      notification.remove();
    });

    // Auto-remove after 10 seconds
    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
      }
    }, 10000);
  }

  async autoUnsubscribe(emailData, unsubscribeLinks) {
    try {
      // Wait for the specified delay
      await this.sleep(this.settings.unsubscribeDelay);
      
      // Click the first unsubscribe link
      if (unsubscribeLinks.length > 0) {
        const firstLink = unsubscribeLinks[0];
        
        console.log(`Auto-unsubscribing from ${emailData.sender} via: ${firstLink.href}`);
        
        // Open unsubscribe link in new tab
        window.open(firstLink.href, '_blank');
        
        // Log the unsubscribe action
        await this.logUnsubscribe(emailData, firstLink);
        
        // Show success notification
        this.showUnsubscribeSuccess(emailData.sender);
      }
    } catch (error) {
      console.error('Error auto-unsubscribing:', error);
    }
  }

  triggerUnsubscribe() {
    // Find and click unsubscribe links
    const unsubscribeLinks = this.findUnsubscribeLinks();
    if (unsubscribeLinks.length > 0) {
      window.open(unsubscribeLinks[0].href, '_blank');
      this.showUnsubscribeSuccess('email sender');
    }
  }

  showUnsubscribeSuccess(sender) {
    const notification = document.createElement('div');
    notification.innerHTML = `
      <div style="
        position: fixed;
        top: 20px;
        right: 20px;
        background: #4caf50;
        color: white;
        padding: 15px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        max-width: 300px;
        font-family: Arial, sans-serif;
        font-size: 14px;
      ">
        <div style="font-weight: bold; margin-bottom: 8px;">✅ Unsubscribed</div>
        <div>Successfully unsubscribed from ${sender}</div>
      </div>
    `;

    document.body.appendChild(notification);

    // Auto-remove after 5 seconds
    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
      }
    }, 5000);
  }

  async logUnsubscribe(emailData, unsubscribeLink) {
    const unsubscribeLog = {
      ...emailData,
      action: 'unsubscribe',
      unsubscribeLink: unsubscribeLink.href,
      timestamp: new Date().toISOString()
    };

    // Store in Chrome storage
    await chrome.storage.local.set({
      unsubscribeLogs: [...(await this.getUnsubscribeLogs()), unsubscribeLog]
    });
  }

  async getUnsubscribeLogs() {
    const result = await chrome.storage.local.get(['unsubscribeLogs']);
    return result.unsubscribeLogs || [];
  }

  async logDeletion(emailData, spamScore) {
    if (!this.settings.logDeletions) return;

    const deletionLog = {
      ...emailData,
      spamScore,
      deletedAt: new Date().toISOString(),
      reason: this.getSpamReason(emailData, spamScore)
    };

    this.deletedEmails.push(deletionLog);
    
    // Store in Chrome storage
    await chrome.storage.local.set({
      deletedEmails: this.deletedEmails.slice(-100) // Keep last 100 entries
    });
  }

  getSpamReason(emailData, spamScore) {
    const reasons = [];
    const text = `${emailData.subject} ${emailData.snippet}`.toLowerCase();
    
    if (text.includes('sponsored')) reasons.push('Sponsored content');
    if (text.includes('advertisement')) reasons.push('Advertisement');
    if (text.includes('promotion')) reasons.push('Promotion');
    if (text.includes('offer')) reasons.push('Marketing offer');
    if (this.isKnownSpamSender(emailData.sender)) reasons.push('Known spam sender');
    
    return reasons.join(', ') || 'High spam score';
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // NEW: Show active indicator
  showActiveIndicator() {
    // Remove existing indicator if any
    const existingIndicator = document.getElementById('spam-detector-status');
    if (existingIndicator) {
      existingIndicator.remove();
    }

    // Create status indicator
    const statusIndicator = document.createElement('div');
    statusIndicator.id = 'spam-detector-status';
    statusIndicator.innerHTML = `
      <div style="
        position: fixed;
        top: 10px;
        left: 10px;
        background: #4caf50;
        color: white;
        padding: 8px 12px;
        border-radius: 6px;
        font-family: Arial, sans-serif;
        font-size: 12px;
        font-weight: bold;
        z-index: 10000;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        display: flex;
        align-items: center;
        gap: 6px;
        cursor: pointer;
        transition: opacity 0.3s ease;
      ">
        <span style="font-size: 14px;">🛡️</span>
        <span>Spam Detector Active</span>
        <span style="font-size: 10px; opacity: 0.8;">v1.0.0</span>
        <button id="toggle-extension" style="
          background: rgba(255,255,255,0.2);
          border: 1px solid rgba(255,255,255,0.3);
          color: white;
          padding: 2px 6px;
          border-radius: 3px;
          font-size: 10px;
          cursor: pointer;
          margin-left: 8px;
        ">Disable</button>
      </div>
    `;

    // Add click event to show settings
    statusIndicator.addEventListener('click', (e) => {
      if (e.target.id !== 'toggle-extension') {
        this.showSettings();
      }
    });

    // Add toggle functionality
    const toggleButton = statusIndicator.querySelector('#toggle-extension');
    toggleButton.addEventListener('click', (e) => {
      e.stopPropagation();
      this.toggleExtension();
    });

    // Add hover effect
    statusIndicator.addEventListener('mouseenter', () => {
      statusIndicator.style.opacity = '1';
    });

    statusIndicator.addEventListener('mouseleave', () => {
      statusIndicator.style.opacity = '0.7';
    });

    document.body.appendChild(statusIndicator);

    // Auto-hide after 5 seconds
    setTimeout(() => {
      if (statusIndicator.parentNode) {
        statusIndicator.style.opacity = '0.3';
      }
    }, 5000);

    // Show again on hover
    statusIndicator.addEventListener('mouseenter', () => {
      statusIndicator.style.opacity = '1';
    });

    // Log that extension is active
    console.log('🛡️ Gmail Spam Detector is now active and monitoring emails');
  }

  // NEW: Toggle extension on/off
  toggleExtension() {
    const statusIndicator = document.getElementById('spam-detector-status');
    const toggleButton = statusIndicator.querySelector('#toggle-extension');
    
    if (this.isEnabled) {
      // Disable extension
      this.isEnabled = false;
      toggleButton.textContent = 'Enable';
      statusIndicator.style.background = '#f44336';
      statusIndicator.querySelector('span:nth-child(2)').textContent = 'Spam Detector Disabled';
      
      // Show notification
      this.showNotification('Extension disabled', 'warning');
      console.log('🛡️ Gmail Spam Detector disabled');
    } else {
      // Enable extension
      this.isEnabled = true;
      toggleButton.textContent = 'Disable';
      statusIndicator.style.background = '#4caf50';
      statusIndicator.querySelector('span:nth-child(2)').textContent = 'Spam Detector Active';
      
      // Show notification
      this.showNotification('Extension enabled', 'success');
      console.log('🛡️ Gmail Spam Detector enabled');
    }
  }

  // NEW: Show notification
  showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: ${type === 'success' ? '#4caf50' : type === 'warning' ? '#ff9800' : '#2196f3'};
      color: white;
      padding: 12px 16px;
      border-radius: 6px;
      font-family: Arial, sans-serif;
      font-size: 14px;
      z-index: 10001;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
      }
    }, 3000);
  }

  injectUI() {
    // Add settings button to Gmail interface
    const toolbar = document.querySelector('[role="toolbar"]');
    if (toolbar && !document.getElementById('spam-detector-settings')) {
      const settingsButton = document.createElement('button');
      settingsButton.id = 'spam-detector-settings';
      settingsButton.innerHTML = '🛡️ Spam Detector';
      settingsButton.style.cssText = `
        margin-left: 10px;
        padding: 8px 12px;
        background: #4285f4;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
      `;
      
      settingsButton.addEventListener('click', () => {
        this.showSettings();
      });
      
      toolbar.appendChild(settingsButton);
    }
  }

  showSettings() {
    // Create settings modal
    const modal = document.createElement('div');
    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.5);
      z-index: 10000;
      display: flex;
      align-items: center;
      justify-content: center;
    `;
    
    modal.innerHTML = `
      <div style="background: white; padding: 20px; border-radius: 8px; min-width: 350px; max-height: 80vh; overflow-y: auto;">
        <h3>Spam Detector Settings</h3>
        
        <div style="margin: 10px 0;">
          <label>
            <input type="checkbox" id="auto-delete" ${this.settings.autoDelete ? 'checked' : ''}>
            Auto-delete detected spam
          </label>
        </div>
        
        <div style="margin: 10px 0;">
          <label>
            <input type="checkbox" id="log-deletions" ${this.settings.logDeletions ? 'checked' : ''}>
            Log deleted emails
          </label>
        </div>
        
        <div style="margin: 10px 0;">
          <label>
            <input type="checkbox" id="auto-unsubscribe" ${this.settings.autoUnsubscribe ? 'checked' : ''}>
            Auto-unsubscribe from newsletters
          </label>
        </div>
        
        <div style="margin: 10px 0;">
          <label>
            Sensitivity: <input type="range" id="sensitivity" min="1" max="10" value="${this.settings.sensitivity}">
            <span id="sensitivity-value">${this.settings.sensitivity}</span>
          </label>
        </div>
        
        <div style="margin: 10px 0;">
          <label>
            Unsubscribe Delay (ms): <input type="number" id="unsubscribe-delay" min="1000" max="10000" value="${this.settings.unsubscribeDelay}">
          </label>
        </div>
        
        <div style="margin-top: 20px;">
          <button id="save-settings" style="background: #4285f4; color: white; border: none; padding: 8px 16px; border-radius: 4px; margin-right: 10px;">Save</button>
          <button id="cancel-settings" style="background: #ccc; border: none; padding: 8px 16px; border-radius: 4px;">Cancel</button>
        </div>
      </div>
    `;
    
    document.body.appendChild(modal);
    
    // Event listeners
    document.getElementById('sensitivity').addEventListener('input', (e) => {
      document.getElementById('sensitivity-value').textContent = e.target.value;
    });
    
    document.getElementById('save-settings').addEventListener('click', async () => {
      this.settings.autoDelete = document.getElementById('auto-delete').checked;
      this.settings.logDeletions = document.getElementById('log-deletions').checked;
      this.settings.autoUnsubscribe = document.getElementById('auto-unsubscribe').checked;
      this.settings.sensitivity = parseInt(document.getElementById('sensitivity').value);
      this.settings.unsubscribeDelay = parseInt(document.getElementById('unsubscribe-delay').value);
      
      await chrome.storage.sync.set({ spamDetectorSettings: this.settings });
      document.body.removeChild(modal);
    });
    
    document.getElementById('cancel-settings').addEventListener('click', () => {
      document.body.removeChild(modal);
    });
  }
}

// Initialize the detector when Gmail is loaded
let spamDetector;

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    spamDetector = new GmailSpamDetector();
  });
} else {
  spamDetector = new GmailSpamDetector();
}

// Handle messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getStatus' && spamDetector) {
    sendResponse({ isEnabled: spamDetector.isEnabled });
  }
  return true;
}); 
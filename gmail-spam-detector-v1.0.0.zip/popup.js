// Popup script for Gmail Spam Detector
class PopupManager {
  constructor() {
    this.init();
  }

  async init() {
    await this.loadSettings();
    this.setupEventListeners();
    this.loadActivityLog();
    this.updateStatistics();
    this.loadUnsubscribeHistory();
    this.checkExtensionStatus();
  }

  async loadSettings() {
    try {
      const response = await chrome.runtime.sendMessage({ action: 'getSettings' });
      if (response) {
        document.getElementById('auto-delete').checked = response.autoDelete || false;
        document.getElementById('log-deletions').checked = response.logDeletions !== false;
        document.getElementById('auto-unsubscribe').checked = response.autoUnsubscribe !== false;
        document.getElementById('sensitivity').value = response.sensitivity || 3;
        document.getElementById('sensitivity-value').textContent = response.sensitivity || 3;
        document.getElementById('unsubscribe-delay').value = response.unsubscribeDelay || 2000;
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  }

  setupEventListeners() {
    // Settings save
    document.getElementById('save-settings').addEventListener('click', async () => {
      const settings = {
        autoDelete: document.getElementById('auto-delete').checked,
        logDeletions: document.getElementById('log-deletions').checked,
        autoUnsubscribe: document.getElementById('auto-unsubscribe').checked,
        sensitivity: parseInt(document.getElementById('sensitivity').value),
        unsubscribeDelay: parseInt(document.getElementById('unsubscribe-delay').value)
      };

      try {
        await chrome.runtime.sendMessage({ 
          action: 'saveSettings', 
          settings: settings 
        });
        
        // Show success message
        const button = document.getElementById('save-settings');
        const originalText = button.textContent;
        button.textContent = 'Saved!';
        button.style.background = '#4caf50';
        
        setTimeout(() => {
          button.textContent = originalText;
          button.style.background = '#4285f4';
        }, 2000);
      } catch (error) {
        console.error('Error saving settings:', error);
      }
    });

    // Sensitivity slider
    document.getElementById('sensitivity').addEventListener('input', (e) => {
      document.getElementById('sensitivity-value').textContent = e.target.value;
    });

    // Tab switching
    document.querySelectorAll('.tab').forEach(tab => {
      tab.addEventListener('click', () => {
        this.switchTab(tab.dataset.tab);
      });
    });

    // Clear log
    document.getElementById('clear-log').addEventListener('click', async () => {
      if (confirm('Are you sure you want to clear the activity log?')) {
        try {
          await chrome.runtime.sendMessage({ action: 'clearActivityLog' });
          this.loadActivityLog();
          this.updateStatistics();
        } catch (error) {
          console.error('Error clearing log:', error);
        }
      }
    });

    // Unsubscribe controls
    document.getElementById('scan-unsubscribe').addEventListener('click', async () => {
      try {
        await chrome.runtime.sendMessage({ action: 'scanUnsubscribeLinks' });
        this.showNotification('Scanning for unsubscribe links...', 'info');
      } catch (error) {
        console.error('Error scanning unsubscribe links:', error);
      }
    });

    document.getElementById('manual-unsubscribe').addEventListener('click', async () => {
      try {
        await chrome.runtime.sendMessage({ action: 'manualUnsubscribe' });
        this.showNotification('Manual unsubscribe triggered', 'info');
      } catch (error) {
        console.error('Error manual unsubscribe:', error);
      }
    });
  }

  switchTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.tab').forEach(tab => {
      tab.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => {
      content.classList.remove('active');
    });
    document.getElementById(`${tabName}-tab`).classList.add('active');
  }

  async loadActivityLog() {
    try {
      const deletedEmails = await chrome.runtime.sendMessage({ action: 'getDeletedEmails' });
      const unsubscribeLogs = await chrome.runtime.sendMessage({ action: 'getUnsubscribeLogs' });
      
      // Combine and sort all activities
      const allActivities = [
        ...(deletedEmails || []).map(item => ({ ...item, type: 'deletion' })),
        ...(unsubscribeLogs || []).map(item => ({ ...item, type: 'unsubscribe' }))
      ];
      
      allActivities.sort((a, b) => new Date(b.timestamp || b.deletedAt) - new Date(a.timestamp || a.deletedAt));
      
      this.displayActivityLog(allActivities);
    } catch (error) {
      console.error('Error loading activity log:', error);
    }
  }

  displayActivityLog(activities) {
    const logContainer = document.getElementById('activity-log');
    
    if (activities.length === 0) {
      logContainer.innerHTML = '<div class="no-log">No activity logged yet</div>';
      return;
    }

    const logHTML = activities.slice(0, 15).map(activity => {
      const isUnsubscribe = activity.type === 'unsubscribe';
      const date = activity.timestamp || activity.deletedAt;
      
      return `
        <div class="log-entry ${isUnsubscribe ? 'unsubscribe-entry' : ''}">
          <div class="log-sender">${this.escapeHtml(activity.sender)}</div>
          <div class="log-subject">${this.escapeHtml(activity.subject)}</div>
          ${isUnsubscribe ? 
            `<div class="log-action">Unsubscribed via: ${this.escapeHtml(activity.unsubscribeLink || 'link')}</div>` :
            `<div class="log-reason">${this.escapeHtml(activity.reason)} (Score: ${activity.spamScore})</div>`
          }
          <div class="log-date">${this.formatDate(date)}</div>
        </div>
      `;
    }).join('');

    logContainer.innerHTML = logHTML;
  }

  async loadUnsubscribeHistory() {
    try {
      const unsubscribeLogs = await chrome.runtime.sendMessage({ action: 'getUnsubscribeLogs' });
      this.displayUnsubscribeHistory(unsubscribeLogs || []);
    } catch (error) {
      console.error('Error loading unsubscribe history:', error);
    }
  }

  displayUnsubscribeHistory(unsubscribeLogs) {
    const container = document.getElementById('unsubscribe-list');
    
    if (unsubscribeLogs.length === 0) {
      container.innerHTML = '<div class="no-log">No unsubscribe history</div>';
      return;
    }

    const historyHTML = unsubscribeLogs.slice(0, 10).map(log => `
      <div class="log-entry unsubscribe-entry">
        <div class="log-sender">${this.escapeHtml(log.sender)}</div>
        <div class="log-subject">${this.escapeHtml(log.subject)}</div>
        <div class="log-action">Unsubscribed: ${this.escapeHtml(log.unsubscribeLink)}</div>
        <div class="log-date">${this.formatDate(log.timestamp)}</div>
      </div>
    `).join('');

    container.innerHTML = historyHTML;
  }

  async updateStatistics() {
    try {
      const deletedEmails = await chrome.runtime.sendMessage({ action: 'getDeletedEmails' });
      const unsubscribeLogs = await chrome.runtime.sendMessage({ action: 'getUnsubscribeLogs' });
      
      const emails = deletedEmails || [];
      const unsubscribes = unsubscribeLogs || [];
      
      document.getElementById('total-deleted').textContent = emails.length;
      document.getElementById('total-unsubscribed').textContent = unsubscribes.length;
    } catch (error) {
      console.error('Error updating statistics:', error);
    }
  }

  showNotification(message, type = 'info') {
    // Create a simple notification
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 10px;
      right: 10px;
      background: ${type === 'info' ? '#2196f3' : '#4caf50'};
      color: white;
      padding: 8px 12px;
      border-radius: 4px;
      font-size: 12px;
      z-index: 10000;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
      }
    }, 3000);
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = (now - date) / (1000 * 60 * 60);

    if (diffInHours < 1) {
      return 'Just now';
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)} hours ago`;
    } else if (diffInHours < 48) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString();
    }
  }

  async checkExtensionStatus() {
    try {
      // Send message to content script to check status
      const response = await chrome.tabs.query({ active: true, currentWindow: true });
      if (response[0] && response[0].url && response[0].url.includes('mail.google.com')) {
        chrome.tabs.sendMessage(response[0].id, { action: 'getStatus' }, (response) => {
          if (response && response.isEnabled !== undefined) {
            this.updateStatusIndicator(response.isEnabled);
          }
        });
      }
    } catch (error) {
      console.error('Error checking extension status:', error);
    }
  }

  updateStatusIndicator(isEnabled) {
    const statusElement = document.getElementById('extension-status');
    if (statusElement) {
      if (isEnabled) {
        statusElement.textContent = '● Active';
        statusElement.className = 'status-active';
      } else {
        statusElement.textContent = '● Inactive';
        statusElement.className = 'status-inactive';
      }
    }
  }
}

// Initialize popup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new PopupManager();
}); 
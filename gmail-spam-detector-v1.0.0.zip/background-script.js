// Background Service Worker for Gmail Spam Detector
chrome.runtime.onInstalled.addListener(() => {
  console.log('Gmail Spam Detector extension installed');
  
  // Set default settings
  chrome.storage.sync.set({
    spamDetectorSettings: {
      autoDelete: false,
      logDeletions: true,
      sensitivity: 3,
      autoUnsubscribe: true,
      unsubscribeDelay: 2000
    }
  });
});

// Handle messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getSettings') {
    chrome.storage.sync.get(['spamDetectorSettings'], (result) => {
      sendResponse(result.spamDetectorSettings || {});
    });
    return true; // Keep message channel open for async response
  }
  
  if (request.action === 'saveSettings') {
    chrome.storage.sync.set({ spamDetectorSettings: request.settings }, () => {
      sendResponse({ success: true });
    });
    return true;
  }
  
  if (request.action === 'getDeletedEmails') {
    chrome.storage.local.get(['deletedEmails'], (result) => {
      sendResponse(result.deletedEmails || []);
    });
    return true;
  }
  
  if (request.action === 'getUnsubscribeLogs') {
    chrome.storage.local.get(['unsubscribeLogs'], (result) => {
      sendResponse(result.unsubscribeLogs || []);
    });
    return true;
  }
  
  if (request.action === 'clearActivityLog') {
    chrome.storage.local.remove(['deletedEmails', 'unsubscribeLogs'], () => {
      sendResponse({ success: true });
    });
    return true;
  }
  
  if (request.action === 'scanUnsubscribeLinks') {
    // Forward to content script
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && tabs[0].url.includes('mail.google.com')) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'scanUnsubscribeLinks' });
      }
    });
    sendResponse({ success: true });
    return true;
  }
  
  if (request.action === 'manualUnsubscribe') {
    // Forward to content script
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && tabs[0].url.includes('mail.google.com')) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'manualUnsubscribe' });
      }
    });
    sendResponse({ success: true });
    return true;
  }
});

// Handle extension icon click
chrome.action.onClicked.addListener((tab) => {
  if (tab.url && tab.url.includes('mail.google.com')) {
    // Open popup or inject settings
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: () => {
        // Trigger settings modal if detector is available
        if (window.gmailSpamDetector) {
          window.gmailSpamDetector.showSettings();
        }
      }
    });
  }
});

// Handle tab updates to inject content script
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('mail.google.com')) {
    // Content script should already be injected via manifest, but we can add additional logic here
    console.log('Gmail tab updated, spam detector ready');
  }
}); 
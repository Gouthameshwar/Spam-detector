# Gmail Spam & Sponsored Email Detector

A Chrome extension that automatically detects and moves spam/sponsored emails to trash in Gmail, with comprehensive logging and user control.

## Features

### 🔍 Smart Detection
- **Content Analysis**: Detects spam keywords and sponsored indicators
- **Sender Analysis**: Identifies known spam senders and domains
- **Pattern Recognition**: Recognizes excessive punctuation and marketing language
- **Configurable Sensitivity**: Adjustable detection threshold (1-10)

### 🗑️ Safe Deletion
- **Direct to Trash**: Emails are moved to Gmail's trash folder (not permanently deleted)
- **Logging System**: Complete record of deleted emails with reasons
- **User Control**: Choose between auto-delete or manual review
- **Undo Protection**: Deleted emails can be recovered from trash

### 📊 Comprehensive Logging
- **Deletion History**: Track all deleted emails with sender, subject, and reason
- **Statistics**: View total and daily deletion counts
- **Detailed Reasons**: See why each email was flagged as spam
- **Export Capability**: Download deletion logs for review

## Installation

### Method 1: Load Unpacked Extension (Development)

1. **Download the Extension**
   ```bash
   git clone <repository-url>
   cd gmail-spam-detector-extension
   ```

2. **Open Chrome Extensions**
   - Open Chrome and go to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top right)

3. **Load the Extension**
   - Click "Load unpacked"
   - Select the extension folder
   - The extension should now appear in your extensions list

### Method 2: Install from Chrome Web Store (When Available)
- Search for "Gmail Spam Detector" in the Chrome Web Store
- Click "Add to Chrome"

## Usage

### Initial Setup

1. **Navigate to Gmail**
   - Go to [mail.google.com](https://mail.google.com)
   - The extension will automatically activate

2. **Configure Settings**
   - Click the extension icon in your browser toolbar
   - Adjust sensitivity and auto-delete preferences
   - Save your settings

### Detection Modes

#### Manual Review Mode (Default)
- Spam emails are highlighted in red
- "SPAM" indicator appears on flagged emails
- You manually decide which emails to delete

#### Auto-Delete Mode
- Spam emails are automatically moved to trash
- All deletions are logged with details
- Review deletion log in extension popup

### Settings Configuration

#### Sensitivity Levels
- **1-3 (Low)**: Only obvious spam detected
- **4-6 (Medium)**: Balanced detection (recommended)
- **7-10 (High)**: Aggressive detection

#### Auto-Delete Options
- **Enabled**: Automatically move spam to trash
- **Disabled**: Highlight spam for manual review

#### Logging Options
- **Enabled**: Track all deleted emails
- **Disabled**: No logging (not recommended)

## Detection Algorithm

The extension uses a multi-factor scoring system:

### Spam Keywords (2 points each)
- sponsored, advertisement, promotion, offer
- limited time, act now, click here, unsubscribe
- special offer, discount, sale, free trial

### Sponsored Indicators (3 points each)
- [AD], [SPONSORED], [PROMOTION]
- sponsored content, paid partnership
- promoted post, sponsored post

### Sender Analysis (4 points)
- Known spam domains (noreply, marketing, etc.)
- Newsletter and promotional senders

### Pattern Analysis (1 point)
- Excessive exclamation marks
- Urgent language patterns

### Threshold System
- **Score ≥ Sensitivity**: Email flagged as spam
- **Score < Sensitivity**: Email considered legitimate

## Safety Features

### Data Privacy
- **Local Processing**: All detection happens in your browser
- **No Data Collection**: No information sent to external servers
- **Chrome Storage**: Settings and logs stored locally

### Deletion Safety
- **Trash Only**: Emails moved to Gmail trash (not permanent deletion)
- **Recovery**: Deleted emails can be restored from trash
- **Logging**: Complete record of all deletions

### User Control
- **Manual Override**: Disable auto-delete for manual review
- **Whitelist**: Add important senders to avoid false positives
- **Settings**: Fine-tune detection sensitivity

## Troubleshooting

### Extension Not Working
1. **Check Permissions**: Ensure extension has access to Gmail
2. **Refresh Gmail**: Reload the Gmail page
3. **Reinstall Extension**: Remove and reload the extension

### False Positives
1. **Adjust Sensitivity**: Lower the sensitivity setting
2. **Review Logs**: Check deletion log for patterns
3. **Whitelist Senders**: Add important senders to safe list

### Missing Emails
1. **Check Trash**: Look in Gmail's trash folder
2. **Review Logs**: Check extension deletion log
3. **Restore**: Move emails from trash back to inbox

## File Structure

```
gmail-spam-detector-extension/
├── manifest.json          # Extension configuration
├── content-script.js      # Main detection logic
├── background-script.js   # Background service worker
├── popup.html            # Extension popup interface
├── popup.js              # Popup functionality
├── package.json          # Project metadata
├── README.md             # This file
└── icons/                # Extension icons
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

## Development

### Prerequisites
- Chrome browser
- Basic knowledge of JavaScript
- Chrome extension development tools

### Local Development
1. **Load Extension**: Use "Load unpacked" in Chrome extensions
2. **Make Changes**: Edit files in your code editor
3. **Reload Extension**: Click reload button in chrome://extensions/
4. **Test**: Navigate to Gmail and test functionality

### Debugging
- **Console Logs**: Check browser console for errors
- **Extension Logs**: View logs in chrome://extensions/
- **Gmail Integration**: Verify Gmail page detection

## Contributing

### Adding Features
1. **Detection Rules**: Add new keywords in `content-script.js`
2. **UI Improvements**: Modify `popup.html` and `popup.js`
3. **Settings**: Extend settings in background script

### Testing
- Test with various email types
- Verify detection accuracy
- Check deletion logging
- Test recovery from trash

## License

MIT License - See LICENSE file for details

## Support

For issues and feature requests:
1. Check the troubleshooting section
2. Review the detection algorithm
3. Test with different sensitivity settings
4. Contact support with detailed logs

## Changelog

### Version 1.0.0
- Initial release
- Basic spam detection
- Auto-delete functionality
- Deletion logging
- Settings management
- Gmail integration 